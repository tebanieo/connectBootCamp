$(document).ready(function () {
    $("#navbar-frame").load("../navbar.html");
});
